import MovieCard from "./MovieCard.jsx";

const MovieGrid = ({ movies, favoriteIds, onToggleFavorite }) => {
  if (!movies.length) {
    return <p className="empty-state">No movies found. Try a different search.</p>;
  }

  return (
    <div className="movie-grid">
      {movies.map((movie) => (
        <MovieCard
          key={movie.id || movie.tmdbId}
          movie={movie}
          isFavorite={favoriteIds.has(movie.id || movie.tmdbId)}
          onToggleFavorite={onToggleFavorite}
        />
      ))}
    </div>
  );
};

export default MovieGrid;
