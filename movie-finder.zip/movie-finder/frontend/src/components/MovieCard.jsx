const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w342";
const FALLBACK_IMAGE = "https://via.placeholder.com/342x513?text=No+Image";

const MovieCard = ({ movie, isFavorite, onToggleFavorite }) => {
  const posterUrl = movie.poster_path
    ? `${IMAGE_BASE_URL}${movie.poster_path}`
    : FALLBACK_IMAGE;

  return (
    <div className="movie-card">
      <img src={posterUrl} alt={movie.title} loading="lazy" />
      <div className="movie-card-body">
        <h3>{movie.title}</h3>
        <p className="release-date">{movie.release_date || "Unknown release date"}</p>
        <p className="rating">⭐ {movie.vote_average?.toFixed(1) ?? "N/A"}</p>
        <button
          className={isFavorite ? "fav-btn active" : "fav-btn"}
          onClick={() => onToggleFavorite(movie)}
        >
          {isFavorite ? "♥ Saved" : "♡ Save"}
        </button>
      </div>
    </div>
  );
};

export default MovieCard;
