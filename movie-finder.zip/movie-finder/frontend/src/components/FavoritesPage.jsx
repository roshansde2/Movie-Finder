import { useEffect, useState } from "react";
import { getFavorites, removeFavorite } from "../api/favoriteApi.js";
import MovieGrid from "./MovieGrid.jsx";

const FavoritesPage = () => {
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadFavorites = async () => {
    setLoading(true);
    try {
      const data = await getFavorites();
      // normalize field names so MovieCard can render them the same way as TMDB results
      const normalized = data.map((f) => ({
        id: f.tmdbId,
        title: f.title,
        poster_path: f.posterPath,
        release_date: f.releaseDate,
        vote_average: f.voteAverage,
      }));
      setFavorites(normalized);
    } catch (err) {
      setError("Failed to load favorites. Is the backend running?");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  const handleToggleFavorite = async (movie) => {
    try {
      await removeFavorite(movie.id);
      setFavorites((prev) => prev.filter((m) => m.id !== movie.id));
    } catch (err) {
      setError("Failed to remove favorite");
    }
  };

  const favoriteIds = new Set(favorites.map((m) => m.id));

  return (
    <div className="page">
      <h2>My Favorites</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && (
        <MovieGrid
          movies={favorites}
          favoriteIds={favoriteIds}
          onToggleFavorite={handleToggleFavorite}
        />
      )}
    </div>
  );
};

export default FavoritesPage;
