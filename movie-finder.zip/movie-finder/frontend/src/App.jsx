import { useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import SearchBar from "./components/SearchBar.jsx";
import MovieGrid from "./components/MovieGrid.jsx";
import FavoritesPage from "./components/FavoritesPage.jsx";
import { searchMovies, getPopularMovies } from "./api/movieApi.js";
import { getFavorites, addFavorite, removeFavorite } from "./api/favoriteApi.js";
import "./App.css";

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [favoriteIds, setFavoriteIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [heading, setHeading] = useState("Popular Movies");

  const loadFavoriteIds = async () => {
    try {
      const favs = await getFavorites();
      setFavoriteIds(new Set(favs.map((f) => f.tmdbId)));
    } catch (err) {
      // favorites are optional context on this page, fail silently
      console.error("Could not load favorites", err);
    }
  };

  const loadPopular = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await getPopularMovies();
      setMovies(data.results || []);
      setHeading("Popular Movies");
    } catch (err) {
      setError("Failed to load movies. Is the backend running?");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPopular();
    loadFavoriteIds();
  }, []);

  const handleSearch = async (query) => {
    setLoading(true);
    setError("");
    try {
      const data = await searchMovies(query);
      setMovies(data.results || []);
      setHeading(`Results for "${query}"`);
    } catch (err) {
      setError("Search failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleFavorite = async (movie) => {
    const isFav = favoriteIds.has(movie.id);
    try {
      if (isFav) {
        await removeFavorite(movie.id);
        setFavoriteIds((prev) => {
          const next = new Set(prev);
          next.delete(movie.id);
          return next;
        });
      } else {
        await addFavorite({
          tmdbId: movie.id,
          title: movie.title,
          posterPath: movie.poster_path,
          overview: movie.overview,
          releaseDate: movie.release_date,
          voteAverage: movie.vote_average,
        });
        setFavoriteIds((prev) => new Set(prev).add(movie.id));
      }
    } catch (err) {
      setError("Could not update favorites");
    }
  };

  return (
    <div className="page">
      <SearchBar onSearch={handleSearch} />
      <h2>{heading}</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && (
        <MovieGrid
          movies={movies}
          favoriteIds={favoriteIds}
          onToggleFavorite={handleToggleFavorite}
        />
      )}
    </div>
  );
};

const App = () => {
  return (
    <div className="app">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/favorites" element={<FavoritesPage />} />
      </Routes>
    </div>
  );
};

export default App;
