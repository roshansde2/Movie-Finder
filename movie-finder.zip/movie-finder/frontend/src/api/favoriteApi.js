import api from "./movieApi.js";

export const getFavorites = async () => {
  const { data } = await api.get("/favorites");
  return data;
};

export const addFavorite = async (movie) => {
  const { data } = await api.post("/favorites", movie);
  return data;
};

export const removeFavorite = async (tmdbId) => {
  const { data } = await api.delete(`/favorites/${tmdbId}`);
  return data;
};
