import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";

const api = axios.create({ baseURL: API_BASE_URL });

export const searchMovies = async (query, page = 1) => {
  const { data } = await api.get("/movies/search", { params: { query, page } });
  return data;
};

export const getPopularMovies = async (page = 1) => {
  const { data } = await api.get("/movies/popular", { params: { page } });
  return data;
};

export const getMovieDetails = async (id) => {
  const { data } = await api.get(`/movies/${id}`);
  return data;
};

export default api;
