import express from "express";
import Favorite from "../models/Favorite.js";

const router = express.Router();

// GET /api/favorites - list all saved favorites
router.get("/", async (req, res) => {
  try {
    const favorites = await Favorite.find().sort({ createdAt: -1 });
    res.json(favorites);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch favorites" });
  }
});

// POST /api/favorites - save a movie to favorites
router.post("/", async (req, res) => {
  const { tmdbId, title, posterPath, overview, releaseDate, voteAverage } = req.body;

  if (!tmdbId || !title) {
    return res.status(400).json({ message: "tmdbId and title are required" });
  }

  try {
    const existing = await Favorite.findOne({ tmdbId });
    if (existing) {
      return res.status(409).json({ message: "Movie already in favorites" });
    }

    const favorite = await Favorite.create({
      tmdbId,
      title,
      posterPath,
      overview,
      releaseDate,
      voteAverage,
    });

    res.status(201).json(favorite);
  } catch (error) {
    res.status(500).json({ message: "Failed to save favorite" });
  }
});

// DELETE /api/favorites/:tmdbId - remove a movie from favorites
router.delete("/:tmdbId", async (req, res) => {
  try {
    const deleted = await Favorite.findOneAndDelete({
      tmdbId: req.params.tmdbId,
    });

    if (!deleted) {
      return res.status(404).json({ message: "Favorite not found" });
    }

    res.json({ message: "Removed from favorites" });
  } catch (error) {
    res.status(500).json({ message: "Failed to remove favorite" });
  }
});

export default router;
