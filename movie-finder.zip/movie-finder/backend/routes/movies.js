import express from "express";
import axios from "axios";

const router = express.Router();

const tmdb = axios.create({
  baseURL: process.env.TMDB_BASE_URL || "https://api.themoviedb.org/3",
  params: {
    api_key: process.env.TMDB_API_KEY,
  },
});

// GET /api/movies/search?query=batman&page=1
router.get("/search", async (req, res) => {
  const { query, page = 1 } = req.query;

  if (!query) {
    return res.status(400).json({ message: "Search query is required" });
  }

  try {
    const { data } = await tmdb.get("/search/movie", {
      params: { query, page, include_adult: false },
    });
    res.json(data);
  } catch (error) {
    console.error("TMDB search error:", error.message);
    res.status(502).json({ message: "Failed to fetch movies from TMDB" });
  }
});

// GET /api/movies/popular?page=1
router.get("/popular", async (req, res) => {
  const { page = 1 } = req.query;

  try {
    const { data } = await tmdb.get("/movie/popular", { params: { page } });
    res.json(data);
  } catch (error) {
    console.error("TMDB popular error:", error.message);
    res.status(502).json({ message: "Failed to fetch popular movies" });
  }
});

// GET /api/movies/:id
router.get("/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const { data } = await tmdb.get(`/movie/${id}`);
    res.json(data);
  } catch (error) {
    console.error("TMDB detail error:", error.message);
    res.status(502).json({ message: "Failed to fetch movie details" });
  }
});

export default router;
